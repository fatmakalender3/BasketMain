This is simple 3d basket ball game functionality and baskey ball ground made in maya

How to use 

1) There is a demo implemented which has 2 modes one is simple arcade mode and another is time based.
2) To access time based you can set the time from inspector view of Basketball gameobject which is child object of Ball_parent_AI.
3) Alter the Time variable of Shoot_AI.cs and set IsTimed variable to true
4) If Time variable has value of 30 it means game will last for 30 seconds (NOTE : please change the slider max value accourdingly).
5) To handle the gameover action use the "Gameover" method inside the script "ShootAI.cs".
6) To change the ball accuracy or speed please handle the values of the variables inside "Shoot.cs" (NOTE: that IF EDITOR CHANGES DO NOT WORK please change the values inside the script).
7) Prefabs are ready to use in any other scene.
8) Ad scene to BUILD SETTINGS in order for replay button to work.
